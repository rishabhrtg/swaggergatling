# OpenAPI JSON
This is a OpenAPI JSON built by the [openapi-generator](https://github.com/openapitools/openapi-genreator) project.