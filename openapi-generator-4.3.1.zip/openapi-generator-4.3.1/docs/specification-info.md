---
id: spec-info
title: Spec Info
---

## OpenAPI

### 2.0

### 3.x

### Tags

Tags basically group endpoints into the same API class file. For example, an endpoint with the `store` tag will be generated in the StoreApi class file in most generators.

Ref: https://github.com/OAI/OpenAPI-Specification/blob/master/versions/2.0.md#tagObject

